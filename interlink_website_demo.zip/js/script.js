
// Fetch Live Crypto Prices
async function fetchPrices() {
    try {
        let response = await fetch("https://api.coingecko.com/api/v3/simple/price?ids=bitcoin,ethereum,chainlink&vs_currencies=usd");
        let data = await response.json();
        document.getElementById("btc-price").innerText = `$${data.bitcoin.usd}`;
        document.getElementById("eth-price").innerText = `$${data.ethereum.usd}`;
        document.getElementById("linkx-price").innerText = `$${data.chainlink.usd}`;
    } catch (error) {
        console.log("Error fetching prices:", error);
    }
}

// Initialize Chart.js for interactive charts
const ctx = document.getElementById('priceChart').getContext('2d');
const priceChart = new Chart(ctx, {
    type: 'line',
    data: {
        labels: ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun'],
        datasets: [{
            label: 'LINKX Price ($)',
            data: [1.2, 1.4, 1.3, 1.8, 2.1, 2.4],
            borderColor: 'rgba(99, 102, 241, 1)',
            borderWidth: 2,
            fill: false
        }]
    },
    options: {
        responsive: true,
    }
});

// Simulated User Registration
function registerUser() {
    alert("User registration is currently in beta. Stay tuned!");
}

// Fetch prices on page load
fetchPrices();
setInterval(fetchPrices, 60000); // Refresh prices every minute
